from boltzmann_wealth_model_network.server import server

server.launch()
