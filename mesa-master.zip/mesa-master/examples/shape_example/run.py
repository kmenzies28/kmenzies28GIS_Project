from shape_example.server import launch_shape_model

launch_shape_model()
