from hex_snowflake.server import server

server.launch()
