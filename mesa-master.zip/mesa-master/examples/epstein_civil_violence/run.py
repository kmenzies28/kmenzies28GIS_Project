from epstein_civil_violence.server import server

server.launch()
