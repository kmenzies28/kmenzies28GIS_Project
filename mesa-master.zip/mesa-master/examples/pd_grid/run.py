from pd_grid.server import server

server.launch()
