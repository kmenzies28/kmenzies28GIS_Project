from color_patches.server import server

server.launch()
