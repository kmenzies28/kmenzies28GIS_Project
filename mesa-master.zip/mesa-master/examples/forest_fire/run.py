from forest_fire.server import server

server.launch()
