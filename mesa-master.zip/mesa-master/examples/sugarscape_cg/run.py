from sugarscape_cg.server import server

server.launch()
