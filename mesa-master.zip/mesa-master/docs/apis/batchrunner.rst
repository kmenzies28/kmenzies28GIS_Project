Batchrunner
-----------

.. automodule:: batchrunner
   :members:
