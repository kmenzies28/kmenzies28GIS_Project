APIs
----

.. toctree::
   :maxdepth: 3

   Base Classes <init>
   batchrunner
   datacollection
   space
   time
   visualization
